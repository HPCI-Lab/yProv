from .documents import documents_bp
from .elements import elements_bp
from .entities import entities_bp
from .activities import activities_bp
from .agents import agents_bp
from .relations import relations_bp
from .auth import auth_bp
